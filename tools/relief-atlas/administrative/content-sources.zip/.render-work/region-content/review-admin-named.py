from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
root=Path.cwd();out=root/'.render-work/region-content/administrative'
entries=json.loads((root/'assets/maps/administrative/landmark-entries.json').read_text(encoding='utf-8'))['entries']
items=list(entries.items());font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',13)
index=[]
for offset in range(0,len(items),40):
 sheet=Image.new('RGB',(1200,960),'#fffdf4');d=ImageDraw.Draw(sheet)
 for j,(pid,e) in enumerate(items[offset:offset+40]):
  i=offset+j;x=j%5*240;y=j//5*120
  im=Image.open(root/e['photo']['src']).convert('RGB');im.thumbnail((236,88));sheet.paste(im,(x,y))
  title=e['label']['zh-CN'];unit=e.get('parentUnit') or e.get('parentCity') or pid.split(':')[2]
  d.text((x,y+88),f'{i:03d} {unit} {title[:13]}',font=font,fill='black')
  index.append({'index':i,'id':pid,'unit':unit,'title':title,'photo':e['photo']})
 sheet.save(out/f'named-review-{offset//40}.jpg',quality=86)
(out/'named-review-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
print(len(items),'named photographs in',(len(items)+39)//40,'contact sheets')
