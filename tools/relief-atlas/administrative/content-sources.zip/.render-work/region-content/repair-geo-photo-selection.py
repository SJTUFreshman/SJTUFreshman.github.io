from pathlib import Path
import importlib.util,copy
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('a',ROOT/'scripts/build-administrative-content.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
d=a.read(a.CACHE/'replacement-photo-options.json')
selection={
'210500':(0,'Benxi steelworks','本溪钢铁工业景观','2013年2月拍摄的本溪钢铁工业景观，厂房与烟囱展现这座城市的工业环境。','Steelworks photographed in Benxi in February 2013, showing the industrial setting of the city.'),
'220300':(0,'Siping memorial monument','四平纪念碑','四平铁西的纪念碑实景，照片记录了夜间照明下的碑体与基座。','A memorial monument in Tiexi, Siping, photographed with its tower and base illuminated at night.'),
'371000':(4,'Weihai municipal hall','威海市政建筑','威海市政建筑及门前广场的实景，呈现城市公共空间与周围山体的关系。','The municipal hall and forecourt in Weihai, set against the hills surrounding the city.'),
'371100':(1,'Rizhao West railway station','日照西站','日照西站的站房实景，展示城区西部铁路客运设施的建筑外观。','The passenger-station building at Rizhao West, a railway gateway on the western side of the city.'),
'350400':(1,'Liexi riverside panorama','三明列西滨水景观','这张列西全景照片记录了三明沿河展开的楼群与周围山地。','A riverside panorama of Liexi in Sanming, with urban buildings framed by the surrounding hills.'),
'451100':(1,'Hezhou railway station','贺州站站台','2026年拍摄的贺州站站台实景，屋盖与轨道展现了当地铁路交通空间。','The platforms and tracks of Hezhou railway station, photographed in 2026.'),
'522300':(6,'Qianxinan ethnic cultural centre','黔西南州民族文化中心','黔西南州民族文化中心的建筑与广场实景，拍摄于2026年8月。','The building and forecourt of the Qianxinan ethnic cultural centre, photographed in August 2026.'),
'522600':(3,'Kaili West freight yard','凯里西站货场','2019年拍摄的凯里西站货场，轨道和铁路建筑记录了城市的运输空间。','The freight yard at Kaili West railway station, photographed in 2019.'),
'420300':(5,'Shiyan city panorama','十堰城区全景','十堰城区全景照片，展示楼群在山谷之间延伸的城市景观。','A panorama of Shiyan showing urban neighbourhoods extending between wooded hills.'),
'653200':(6,'Hotan Unity Square','和田团结广场','和田团结广场的北向实景，广场中央可见毛泽东与库尔班·吐鲁木的雕像。','A north-facing view of Unity Square in Hotan, with the statue of Mao Zedong and Kurban Tulum at its centre.'),
'654200':(0,'Tarbagatai city remains','塔尔巴哈台城遗址','塔尔巴哈台城遗址的现场照片，保留的夯土构筑物显示了昔日城防的建筑材料与形态。','Surviving earthen structures at the Tarbagatai city remains, showing the materials and form of the former fortifications.'),
'620400':(5,'Baiyin No. 1 Middle School grounds','白银市第一中学操场','白银市第一中学的操场与校园建筑实景，提供了当地城市生活的一个侧面。','The sports grounds and buildings of Baiyin No. 1 Middle School, a view of everyday urban life.'),
'659004':(6,'Wujiaqu public square','五家渠城市广场','五家渠广场的冬日实景，树木、道路和广场设施展现了当地公共空间。','A winter view of a public square in Wujiaqu, showing its avenues, trees and open space.')}
entries={};reject={}
old=a.read(a.OUT/'geotagged-landmark-entries.json')['entries']
bad=['210500','220300','371000','371100','350400','451100','460300','469027','512000','522300','522600','420300','653200','654200','620400','659004','632300']
for pid,e in old.items():
    if e['parentUnit'] in bad:reject[pid]='Visual review: object, sign, illustration or interior close-up does not represent a local landscape.'
for key,(index,en,cn,zhtext,entext) in selection.items():
    item=d['choices'][key][index];photo=copy.deepcopy(d['photos'][item['title'][5:]]);point=[item['lon'],item['lat']]
    photo['type']='field-photograph';photo['publishedLocation']={'lngLat':point,'source':photo['source']}
    pid=f'poi:admin:{key}:reviewed-photo-{item["pageid"]}'
    entries[pid]={'label':a.label(en,cn),'description':a.label(entext,zhtext),'source':photo['source'],'textSources':[photo['source']],
      'textKind':'editorial-locality','textLicense':'Original editorial caption based on the linked photograph and its published description.',
      'photo':photo,'lngLat':point,'coordinateSource':photo['source'],'coordinateDerivation':'Published Wikimedia Commons photograph coordinate; not a substituted city centroid.',
      'kind':'landmark','role':'photo-location','parentUnit':key}
a.write(ROOT/'scripts/administrative-rejected-photos.json',reject)
a.write(ROOT/'.render-work/region-content/admin-reviewed-geotagged.json',{'entries':entries})
print('Reviewed replacements:',len(entries),'Rejected originals:',len(reject))
