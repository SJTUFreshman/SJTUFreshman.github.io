from pathlib import Path
import importlib.util,json,sys,concurrent.futures
from urllib.parse import urlencode
from PIL import Image,ImageOps,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('a',ROOT/'scripts/build-administrative-content.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',14)
if sys.argv[1]=='sheet':
    entries=a.read(a.OUT/'geotagged-landmark-entries.json')['entries']
    items=list(entries.items())
    for offset in range(0,len(items),40):
        sheet=Image.new('RGB',(1000,800),'#fffdf4');d=ImageDraw.Draw(sheet)
        for i,(pid,e) in enumerate(items[offset:offset+40]):
            x=i%5*200;y=i//5*100
            im=Image.open(ROOT/e['photo']['src']).convert('RGB');im.thumbnail((196,73));sheet.paste(im,(x,y))
            d.text((x,y+73),pid.split(':')[2]+' '+e['label']['zh-CN'][:9],font=font,fill='black')
        sheet.save(a.CACHE/f'geotag-review-{offset//40}.jpg')
elif sys.argv[1]=='search':
    data=a.base.fetch('https://commons.wikimedia.org/w/api.php?'+urlencode(dict(action='query',format='json',list='categorymembers',cmtitle='Category:Wudu, Longnan',cmtype='file',cmlimit=100)))
    files=[v['title'][5:] for v in data['query']['categorymembers']]
    print(json.dumps(files,ensure_ascii=False))
    a.write(a.CACHE/'wudu-files.json',files)
    wanted=[f for f in files if '202609' in f]
    metadata=a.base.image_metadata(wanted)
    def photo(f):
        try:return f,a.base.licensed_photograph({'pageimage':f,'title':f},metadata)
        except Exception as ex:return f,{'error':str(ex)}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:photos=dict(pool.map(photo,wanted))
    a.write(a.CACHE/'wudu-candidates.json',photos)
    sheet=Image.new('RGB',(1000,((len(photos)+4)//5)*130),'#fffdf4');d=ImageDraw.Draw(sheet)
    for i,(f,p) in enumerate(photos.items()):
        if 'src' not in p:continue
        x=i%5*200;y=i//5*130
        im=Image.open(ROOT/p['src']).convert('RGB');im.thumbnail((196,105));sheet.paste(im,(x,y));d.text((x,y+106),f[-9:],font=font,fill='black')
    sheet.save(a.CACHE/'wudu-contact.jpg')
elif sys.argv[1]=='osm':
    query='[out:json];way["name"](38.48,102.16,38.54,102.22);out center geom;'
    data=a.base.fetch('https://overpass-api.de/api/interpreter?'+urlencode({'data':query}))
    a.write(a.CACHE/'jinchang-tianshui-osm.json',data)
    print(json.dumps([{'id':e['id'],'name':e.get('tags',{}).get('name'),'center':e.get('center')} for e in data['elements']],ensure_ascii=False))
elif sys.argv[1]=='alternatives':
    keys=sys.argv[2:] or ['210500','220300','371000','371100','350400','451100','512000','522300','522600','420300','653200','654200','620400','659004','632300']
    suffix='gap-' if sys.argv[2:] else ''
    import re
    choices=a.read(a.CACHE/'geotagged-photos.json')
    excluded=re.compile(r'ISS\d|STS\d|View of Earth|satellite|Landsat|SRTM|ASTER|map|地图|地图|Frot|Monster Energy|Samsung|SIM卡|Citro|Dongfeng|Isuzu|Suzuki|Volkswagen|Nissan|Gleagle|Changfeng|Huanghai|Selfie|Portrait|Garrulax|flower|flowers|吃|菜肴|食品|food|flower|牌子',re.I)
    allphotos={};selected={}
    for key in keys:
        old=next((e['photo']['originalFile'] for e in a.read(a.OUT/'geotagged-landmark-entries.json')['entries'].values() if e['parentUnit']==key),None)
        pool=[v for v in choices[key] if not excluded.search(v['title']) and v['title'][5:]!=old][:10]
        selected[key]=pool
        allphotos.update({p['title'][5:]:p for p in pool})
    meta=a.base.image_metadata(list(allphotos))
    def photo(f):
        try:return f,a.base.licensed_photograph({'pageimage':f,'title':f},meta)
        except Exception as ex:return f,{'error':str(ex)}
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:photos=dict(pool.map(photo,allphotos))
    a.write(a.CACHE/(suffix+'replacement-photo-options.json'),{'choices':selected,'photos':photos})
    for offset in range(0,len(keys),5):
        sheet=Image.new('RGB',(1500,650),'#fffdf4');d=ImageDraw.Draw(sheet)
        for row,key in enumerate(keys[offset:offset+5]):
            for i,candidate in enumerate(selected[key]):
                p=photos[candidate['title'][5:]]
                if 'src' not in p:continue
                x=i*150;y=row*130
                im=Image.open(ROOT/p['src']).convert('RGB');im.thumbnail((146,105));sheet.paste(im,(x,y));d.text((x,y+106),key+' #'+str(i),font=font,fill='black')
        sheet.save(a.CACHE/f'{suffix}replacement-review-{offset//5}.jpg')
elif sys.argv[1]=='gansu':
    import requests
    queries=['Jinchang','金昌','"陇南市汉王镇"']
    for term in queries:
        data=a.base.fetch('https://commons.wikimedia.org/w/api.php?'+urlencode(dict(action='query',format='json',generator='search',gsrsearch=term,gsrnamespace=6,gsrlimit=50,prop='coordinates|imageinfo',coprimary='all',iiprop='url|extmetadata',iiurlwidth=960)))
        a.write(a.CACHE/('search-'+str(queries.index(term))+'.json'),data)
        print(term,json.dumps([{'title':p['title'],'coordinates':p.get('coordinates'),'description':a.base.plain(p.get('imageinfo',[{}])[0].get('extmetadata',{}).get('ImageDescription',{}).get('value',''))[:150]} for p in data.get('query',{}).get('pages',{}).values()],ensure_ascii=False))
    url='https://www.amap.com/service/poiInfo?'+urlencode({'query_type':'TQUERY','pagesize':10,'pagenum':1,'keywords':'金昌天水路步行街'})
    response=requests.get(url,timeout=30);(a.CACHE/'jinchang-amap.json').write_text(response.text,encoding='utf-8');print(response.text[:3000])
elif sys.argv[1]=='finalgansu':
    names=['20060423105630.jpg','陇南市汉王镇 - Mapillary (jCkYdXcqFvPFf4e6EoWBI5).jpg','陇南市两水镇 - Mapillary (rhnhbTrMKW852EKUjylBkO).jpg']
    meta=a.base.image_metadata(names);out={}
    for name in names:out[name]=a.base.licensed_photograph({'pageimage':name,'title':name},meta)
    a.write(a.CACHE/'final-gansu-photos.json',out)
    print(json.dumps(out,ensure_ascii=False))
elif sys.argv[1]=='laststations':
    titles=['双鸭山西站','双鸭山站','衢州站','衢州孔氏南宗家庙']
    pages=a.base.pages(titles,'zh');a.write(a.CACHE/'last-stations.json',pages)
    meta=a.base.image_metadata([p['pageimage'] for p in pages.values() if p.get('pageimage')]);photos={}
    for title,p in pages.items():
        if p.get('pageimage'):
            try:photos[title]=a.base.licensed_photograph(p,meta)
            except Exception as e:photos[title]={'error':str(e)}
    a.write(a.CACHE/'last-stations-photos.json',photos)
    print(json.dumps({k:{'coord':v.get('coordinates'),'image':v.get('pageimage'),'photo':photos.get(k)} for k,v in pages.items()},ensure_ascii=False))
