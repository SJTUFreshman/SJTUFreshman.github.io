'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const DIR = __dirname;
const load = file => JSON.parse(fs.readFileSync(path.join(DIR, file), 'utf8').replace(/^\uFEFF/, ''));
function polygons(files) {
    const elements = new Map();
    files.forEach(file => load(file).elements.forEach(item => elements.set(item.type + item.id, item)));
    const nodes = new Map([...elements.values()].filter(item => item.type === 'node').map(item => [item.id, [item.lon, item.lat]]));
    const coast = [...elements.values()].filter(item => item.type === 'way' && item.tags?.natural === 'coastline');
    const pending = coast.map(item => ({ nodes: [...item.nodes], ways: [item.id] })), rings = [];
    while (pending.length) {
        const ring = pending.shift();
        while (ring.nodes[0] !== ring.nodes.at(-1)) {
            const end = ring.nodes.at(-1), index = pending.findIndex(item => item.nodes[0] === end || item.nodes.at(-1) === end);
            assert(index >= 0, 'Incomplete coastline: ' + ring.ways.join(','));
            const part = pending.splice(index, 1)[0];
            // OSM coastlines keep the land to their left; retain this winding.
            assert(part.nodes[0] === end, 'Coastline direction conflict: ' + part.ways.join(','));
            ring.nodes.push(...part.nodes.slice(1)); ring.ways.push(...part.ways);
        }
        const coordinates = ring.nodes.map(id => { assert(nodes.has(id), 'Missing OSM node ' + id); return nodes.get(id); });
        const signedArea = coordinates.reduce((sum, point, i) => sum + (i ? coordinates[i - 1][0] * point[1] - point[0] * coordinates[i - 1][1] : 0), 0) / 2;
        assert(signedArea > 0, 'Unexpected water-hole ring; requires explicit hole assignment');
        rings.push({ coordinates, ways: ring.ways });
    }
    return { rings, wayIds: coast.map(item => item.id) };
}
function feature(id, name, files, sourceApis, extra = {}) {
    const { rings, wayIds } = polygons(files);
    return { type: 'Feature', id, properties: {
        id, name, source_crs: 'EPSG:4326', source: 'https://www.openstreetmap.org',
        source_apis: sourceApis, osm_way_ids: wayIds, land_patches: rings.length,
        attribution: 'OpenStreetMap contributors', license: 'ODbL 1.0',
        license_url: 'https://opendatacommons.org/licenses/odbl/1-0/', retrieved: '2026-11-16',
        derivation: 'Exact directed assembly of natural=coastline ways. Reef, shoal, maritime and administrative outlines are excluded. No buffer, simplification or invented land.', ...extra
    }, geometry: { type: 'MultiPolygon', coordinates: rings.map(ring => [ring.coordinates]) } };
}
const paracelFiles = fs.readdirSync(DIR).filter(file => /^paracels-tile-\d-\d\.json$/.test(file));
assert.equal(paracelFiles.length, 20);
const paracelApis = paracelFiles.map(file => {
    const [, x, y] = file.match(/tile-(\d)-(\d)/);
    const box = [111.1 + x * .4, 15.65 + y * .4, 111.1 + (Number(x) + 1) * .4, 15.65 + (Number(y) + 1) * .4];
    return 'https://api.openstreetmap.org/api/0.6/map.json?bbox=' + box.map(value => value.toFixed(2)).join(',');
});
const specs = [
    ['Yongshu', '永暑礁 / Fiery Cross Reef', 'fiery-cross', [112.85, 9.50, 113.02, 9.65]],
    ['Meiji', '美济礁 / Mischief Reef', 'mischief', [115.50, 9.88, 115.57, 9.94]],
    ['Zhubi', '渚碧礁 / Subi Reef', 'subi', [114.05, 10.90, 114.11, 10.95]],
    ['Huayang', '华阳礁 / Cuarteron Reef', 'cuarteron', [112.81, 8.85, 112.86, 8.90]],
    ['Chigua', '赤瓜礁 / Johnson South Reef', 'johnson-south', [114.27, 9.70, 114.31, 9.74]],
    ['Nanxun', '南薰礁 / Gaven Reef', 'gaven', [114.20, 10.19, 114.24, 10.24]],
    ['Dongmen', '东门礁 / Hughes Reef', 'hughes', [114.48, 9.89, 114.52, 9.94]]
];
const result = { type: 'FeatureCollection', name: 'Sansha actual island-land guide',
    metadata: {
        scope: 'Mapped above-water land in the Paracel Islands, plus seven PRC-administered Spratly reef outposts; this is not a boundary or sovereignty-claim polygon.',
        exclusions: 'Submerged reef flats, open sea, administrative claim lines, Taiwan-administered Taiping and other parties\' occupied land are not terrain masks.',
        coastlineSource: 'OpenStreetMap natural=coastline, retrieved 2026-11-16',
        scopeSources: ['https://amti.csis.org/island-tracker/china/', 'https://zh.wikipedia.org/wiki/三沙市'],
        attribution: 'OpenStreetMap contributors', license: 'ODbL 1.0'
    },
    features: [feature('SCS:Xisha', '西沙群岛 / Paracel Islands', paracelFiles, paracelApis, { group: 'Paracels', sampledBounds: [111.1, 15.65, 113.1, 17.25] }),
        ...specs.map(([id, name, slug, bounds]) => feature('SCS:' + id, name, [slug + '-osm-source.json'], ['https://api.openstreetmap.org/api/0.6/map.json?bbox=' + bounds.join(',')], { group: 'Spratlys', sampledBounds: bounds }))]
};
fs.writeFileSync(path.join(DIR, 'sansha-controlled-land.geojson'), JSON.stringify(result));
console.log(JSON.stringify(result.features.map(item => ({ id: item.id, patches: item.properties.land_patches, coastWays: item.properties.osm_way_ids.length }))));
